export const onRequest = ({ next }) => {
  return next();
};
