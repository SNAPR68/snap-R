create index if not exists idx_photos_listing_status on photos(listing_id, status);
