# snap-R

AI-powered photo enhancement and real estate image optimization app.

Built with Next.js, Supabase, and an AI image enhancement pipeline.

