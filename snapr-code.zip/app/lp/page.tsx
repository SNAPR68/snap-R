'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import { 
  Sparkles, 
  Clock, 
  Zap, 
  Check, 
  ArrowRight, 
  Play,
  Camera,
  Palette,
  Share2,
  Globe,
  Mail,
  Video,
  Sun,
  Home,
  Sofa,
  TreePine,
  Eraser,
  ImagePlus,
  Layers,
  Star,
  ChevronDown,
  Menu,
  X,
  Upload,
  Wand2
} from 'lucide-react'

// ============================================
// ANIMATED DEMO COMPONENT
// ============================================
function AnimatedDemo() {
  const [phase, setPhase] = useState(0) // 0=upload, 1=processing, 2=complete
  const [uploadPct, setUploadPct] = useState(0)
  const [procStep, setProcStep] = useState(0)
  const [procPct, setProcPct] = useState(0)
  const [sliderPos, setSliderPos] = useState(50)
  const [sliderDir, setSliderDir] = useState(-1)
  const [showContent, setShowContent] = useState(false)
  const [holdTime, setHoldTime] = useState(0)

  const steps = ['Analyzing lighting...', 'Detecting rooms...', 'Enhancing colors...', 'Applying HDR...', 'Replacing sky...', 'Final polish...']
  const content = ['12 Instagram Posts', '8 Facebook Posts', '4 LinkedIn Posts', '6 Email Templates', 'Property Website', 'Virtual Tour']

  useEffect(() => {
    const interval = setInterval(() => {
      setPhase(currentPhase => {
        if (currentPhase === 0) {
          // Upload phase
          setUploadPct(prev => {
            if (prev >= 100) {
              setHoldTime(h => {
                if (h > 5) {
                  setHoldTime(0)
                  return 0
                }
                return h + 1
              })
              if (holdTime > 5) {
                return 0
              }
              return prev
            }
            return prev + 3
          })
          
          if (uploadPct >= 100 && holdTime > 5) {
            setUploadPct(0)
            setHoldTime(0)
            return 1
          }
          return 0
        } else if (currentPhase === 1) {
          // Processing phase
          setProcPct(prev => {
            if (prev >= 100) {
              setProcStep(s => {
                if (s >= 5) {
                  setHoldTime(h => h + 1)
                  if (holdTime > 3) {
                    setProcStep(0)
                    setProcPct(0)
                    setHoldTime(0)
                    setPhase(2)
                  }
                  return s
                }
                setProcPct(0)
                return s + 1
              })
              return 0
            }
            return prev + 8
          })
          
          if (procStep >= 5 && holdTime > 3) {
            return 2
          }
          return 1
        } else {
          // Complete phase
          setSliderPos(prev => {
            let newPos = prev + sliderDir * 2
            if (newPos <= 20) {
              setSliderDir(1)
              newPos = 20
            }
            if (newPos >= 80) {
              setSliderDir(-1)
              setHoldTime(h => h + 1)
              newPos = 80
            }
            return newPos
          })
          
          if (holdTime > 2 && !showContent) {
            setShowContent(true)
          }
          
          if (holdTime > 30) {
            // Reset everything
            setUploadPct(0)
            setProcStep(0)
            setProcPct(0)
            setSliderPos(50)
            setSliderDir(-1)
            setShowContent(false)
            setHoldTime(0)
            return 0
          }
          return 2
        }
      })
    }, 80)

    return () => clearInterval(interval)
  }, [uploadPct, procStep, holdTime, showContent, sliderDir])

  return (
    <div className="relative rounded-2xl overflow-hidden border border-white/10 bg-black/60 shadow-2xl shadow-[#D4A017]/10">
      {/* Phase Indicator */}
      <div className="absolute top-4 left-1/2 -translate-x-1/2 z-20 flex items-center gap-2">
        {[0, 1, 2].map((p) => (
          <div key={p} className="flex items-center">
            <div className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-semibold transition-all duration-300 ${
              phase === p ? 'bg-[#D4A017] text-black scale-110' : phase > p ? 'bg-[#D4A017]/30 text-[#D4A017]' : 'bg-white/10 text-white/40'
            }`}>
              {phase > p ? '✓' : p + 1}
            </div>
            {p < 2 && <div className={`w-8 h-0.5 mx-1 transition-all ${phase > p ? 'bg-[#D4A017]' : 'bg-white/10'}`} />}
          </div>
        ))}
      </div>

      {/* Upload Phase */}
      {phase === 0 && (
        <div className="aspect-video flex flex-col items-center justify-center p-8">
          <div className="w-16 h-16 rounded-2xl bg-[#D4A017]/20 flex items-center justify-center mb-4 animate-bounce">
            <Upload className="w-8 h-8 text-[#D4A017]" />
          </div>
          <p className="text-white/60 mb-4">Uploading 25 photos...</p>
          <div className="w-48 h-1.5 bg-white/10 rounded-full overflow-hidden mb-2">
            <div className="h-full bg-gradient-to-r from-[#D4A017] to-[#B8860B] transition-all duration-75" style={{ width: `${uploadPct}%` }} />
          </div>
          <p className="text-[#D4A017] font-bold">{Math.min(uploadPct, 100)}%</p>
          <div className="grid grid-cols-5 gap-1.5 mt-4">
            {Array.from({ length: Math.min(Math.floor(uploadPct / 4), 25) }).map((_, i) => (
              <div key={i} className="w-8 h-8 rounded bg-white/10 flex items-center justify-center text-white/40 text-xs">
                🖼
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Processing Phase */}
      {phase === 1 && (
        <div className="aspect-video flex flex-col items-center justify-center p-8">
          <div className="w-16 h-16 rounded-2xl bg-[#D4A017]/20 flex items-center justify-center mb-4 animate-pulse">
            <Wand2 className="w-8 h-8 text-[#D4A017]" />
          </div>
          <p className="text-white font-medium mb-1">AI Enhancement in Progress</p>
          <p className="text-white/40 text-sm mb-4">Processing 25 photos</p>
          <div className="space-y-2 w-56">
            {steps.map((step, i) => (
              <div key={i} className={`flex items-center gap-2 transition-opacity ${i < procStep ? 'opacity-50' : i === procStep ? 'opacity-100' : 'opacity-30'}`}>
                <div className={`w-6 h-6 rounded flex items-center justify-center text-xs ${
                  i < procStep ? 'bg-green-500/20 text-green-400' : i === procStep ? 'bg-[#D4A017]/20 text-[#D4A017]' : 'bg-white/5 text-white/30'
                }`}>
                  {i < procStep ? '✓' : '●'}
                </div>
                <div className="flex-1">
                  <p className="text-xs text-white/80">{step}</p>
                  {i === procStep && (
                    <div className="h-0.5 bg-white/10 rounded-full mt-1 overflow-hidden">
                      <div className="h-full bg-[#D4A017] transition-all" style={{ width: `${procPct}%` }} />
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
          <p className="text-[#D4A017] mt-4 text-2xl font-bold">{Math.floor(procStep * 5 + procPct / 20)}s</p>
          <p className="text-white/40 text-xs">Competitors take 24-48 hours</p>
        </div>
      )}

      {/* Complete Phase */}
      {phase === 2 && (
        <div className="aspect-video flex flex-col">
          {/* Before/After */}
          <div className="relative flex-1 overflow-hidden">
            <img 
              src="https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=800&q=80" 
              alt="Before" 
              className="absolute inset-0 w-full h-full object-cover brightness-[0.7] saturate-[0.7]"
            />
            <div className="absolute top-3 left-3 px-2 py-0.5 bg-black/70 rounded-full text-white text-[10px] font-medium z-10">BEFORE</div>
            
            <div className="absolute inset-0 overflow-hidden" style={{ clipPath: `inset(0 ${100 - sliderPos}% 0 0)` }}>
              <img 
                src="https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=800&q=80" 
                alt="After" 
                className="absolute inset-0 w-full h-full object-cover"
              />
              <div className="absolute top-3 left-3 px-2 py-0.5 bg-[#D4A017] rounded-full text-black text-[10px] font-bold">AFTER</div>
            </div>
            
            <div className="absolute top-0 bottom-0 w-0.5 bg-white shadow-lg z-20" style={{ left: `${sliderPos}%`, transform: 'translateX(-50%)' }}>
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-7 h-7 rounded-full bg-white shadow-lg flex items-center justify-center text-xs">⇔</div>
            </div>
          </div>
          
          {/* Content */}
          <div className="p-4 border-t border-white/10 bg-black/40">
            <div className="flex items-center gap-2 mb-2">
              <Check className="w-4 h-4 text-green-400" />
              <span className="text-white text-sm font-medium">25 Photos Enhanced</span>
              <span className="text-[#D4A017] ml-auto text-xs">+ Marketing Content Ready</span>
            </div>
            {showContent && (
              <div className="grid grid-cols-3 gap-1.5">
                {content.map((item, i) => (
                  <div key={i} className="px-2 py-1 bg-[#D4A017]/10 border border-[#D4A017]/20 rounded text-[10px] text-white/80 text-center">
                    {item}
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  )
}

// ============================================
// NAVIGATION
// ============================================
function Navigation() {
  const [isScrolled, setIsScrolled] = useState(false)
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 20)
    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
      isScrolled ? 'bg-black/90 backdrop-blur-xl border-b border-white/10' : 'bg-transparent'
    }`}>
      <div className="max-w-7xl mx-auto px-6 py-4">
        <div className="flex items-center justify-between">
          <Link href="/" className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#D4A017] to-[#B8860B] flex items-center justify-center">
              <Camera className="w-5 h-5 text-black" />
            </div>
            <span className="text-xl font-bold text-white">Snap<span className="text-[#D4A017]">R</span></span>
          </Link>

          <div className="hidden md:flex items-center gap-8">
            <a href="#features" className="text-white/70 hover:text-white transition-colors text-sm">Features</a>
            <a href="#how-it-works" className="text-white/70 hover:text-white transition-colors text-sm">How It Works</a>
            <a href="#pricing" className="text-white/70 hover:text-white transition-colors text-sm">Pricing</a>
          </div>

          <div className="hidden md:flex items-center gap-4">
            <Link href="/login" className="text-white/70 hover:text-white transition-colors text-sm">Log In</Link>
            <Link href="/signup" className="px-5 py-2.5 bg-[#D4A017] hover:bg-[#B8860B] text-black font-semibold rounded-lg text-sm transition-all">
              Start Free
            </Link>
          </div>

          <button className="md:hidden text-white" onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {mobileMenuOpen && (
          <div className="md:hidden mt-4 pb-4 border-t border-white/10 pt-4">
            <div className="flex flex-col gap-4">
              <a href="#features" className="text-white/70 hover:text-white transition-colors">Features</a>
              <a href="#how-it-works" className="text-white/70 hover:text-white transition-colors">How It Works</a>
              <a href="#pricing" className="text-white/70 hover:text-white transition-colors">Pricing</a>
              <Link href="/login" className="text-white/70 hover:text-white transition-colors">Log In</Link>
              <Link href="/signup" className="px-5 py-2.5 bg-[#D4A017] hover:bg-[#B8860B] text-black font-semibold rounded-lg text-center transition-all">
                Start Free
              </Link>
            </div>
          </div>
        )}
      </div>
    </nav>
  )
}

// ============================================
// HERO SECTION
// ============================================
function HeroSection() {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden pt-20">
      <div className="absolute inset-0 bg-gradient-to-b from-black via-black to-[#0a0a0a]" />
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,rgba(212,160,23,0.15),transparent_50%)]" />
      
      <div className="absolute inset-0 opacity-20" style={{
        backgroundImage: 'linear-gradient(rgba(212,160,23,0.1) 1px, transparent 1px), linear-gradient(90deg, rgba(212,160,23,0.1) 1px, transparent 1px)',
        backgroundSize: '50px 50px'
      }} />

      <div className="relative z-10 max-w-7xl mx-auto px-6 py-12 text-center">
        <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-[#D4A017]/10 border border-[#D4A017]/30 mb-6">
          <Sparkles className="w-4 h-4 text-[#D4A017]" />
          <span className="text-[#D4A017] text-sm font-medium">AI-Powered Photo Enhancement</span>
        </div>

        <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold text-white leading-tight mb-6">
          Real Estate Photos.
          <br />
          <span className="text-[#D4A017]">Perfected in Seconds.</span>
        </h1>

        <p className="text-lg md:text-xl text-white/60 max-w-2xl mx-auto mb-6">
          Transform ordinary property photos into stunning visuals with AI. 
          Sky replacement, HDR, virtual staging, and more — all in under 60 seconds.
        </p>

        <div className="flex flex-wrap items-center justify-center gap-6 mb-8">
          <div className="flex items-center gap-2">
            <Clock className="w-5 h-5 text-[#D4A017]" />
            <span className="text-white"><strong className="text-[#D4A017]">60 sec</strong> not 24 hours</span>
          </div>
          <div className="flex items-center gap-2">
            <Palette className="w-5 h-5 text-[#D4A017]" />
            <span className="text-white"><strong className="text-[#D4A017]">15+</strong> AI tools</span>
          </div>
          <div className="flex items-center gap-2">
            <Layers className="w-5 h-5 text-[#D4A017]" />
            <span className="text-white"><strong className="text-[#D4A017]">150+</strong> templates</span>
          </div>
        </div>

        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-10">
          <Link href="/signup" className="w-full sm:w-auto px-8 py-4 bg-[#D4A017] hover:bg-[#B8860B] text-black font-bold rounded-xl text-lg transition-all flex items-center justify-center gap-2 group">
            Start Free Trial
            <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </Link>
          <Link href="/signup" className="w-full sm:w-auto px-8 py-4 bg-white/10 hover:bg-white/20 text-white font-semibold rounded-xl text-lg transition-all flex items-center justify-center gap-2 border border-white/20">
            <Play className="w-5 h-5" />
            Watch Demo
          </Link>
        </div>

        {/* Animated Demo */}
        <div className="max-w-3xl mx-auto">
          <AnimatedDemo />
        </div>

        <div className="mt-8 flex flex-wrap items-center justify-center gap-8 text-white/40 text-sm">
          <span>Trusted by 1,000+ real estate professionals</span>
          <div className="flex items-center gap-1">
            {[...Array(5)].map((_, i) => (
              <Star key={i} className="w-4 h-4 fill-[#D4A017] text-[#D4A017]" />
            ))}
            <span className="ml-2">4.9/5 rating</span>
          </div>
        </div>
      </div>

      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
        <ChevronDown className="w-6 h-6 text-white/40" />
      </div>
    </section>
  )
}

// ============================================
// PROBLEM/SOLUTION SECTION
// ============================================
function ProblemSolutionSection() {
  return (
    <section className="py-20 bg-[#0a0a0a]">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div className="p-8 rounded-2xl bg-red-500/5 border border-red-500/20">
            <h3 className="text-red-400 font-semibold mb-4 flex items-center gap-2">
              <X className="w-5 h-5" />
              The Old Way
            </h3>
            <ul className="space-y-4 text-white/70">
              <li className="flex items-start gap-3">
                <X className="w-5 h-5 text-red-400 mt-0.5 flex-shrink-0" />
                <span>Wait 24-48 hours for photo edits from outsourced editors</span>
              </li>
              <li className="flex items-start gap-3">
                <X className="w-5 h-5 text-red-400 mt-0.5 flex-shrink-0" />
                <span>Pay $5-25 per image for basic enhancements</span>
              </li>
              <li className="flex items-start gap-3">
                <X className="w-5 h-5 text-red-400 mt-0.5 flex-shrink-0" />
                <span>Manually create social posts, emails, and marketing materials</span>
              </li>
              <li className="flex items-start gap-3">
                <X className="w-5 h-5 text-red-400 mt-0.5 flex-shrink-0" />
                <span>Juggle multiple tools and subscriptions</span>
              </li>
            </ul>
          </div>

          <div className="p-8 rounded-2xl bg-[#D4A017]/5 border border-[#D4A017]/20">
            <h3 className="text-[#D4A017] font-semibold mb-4 flex items-center gap-2">
              <Check className="w-5 h-5" />
              The SnapR Way
            </h3>
            <ul className="space-y-4 text-white/70">
              <li className="flex items-start gap-3">
                <Check className="w-5 h-5 text-[#D4A017] mt-0.5 flex-shrink-0" />
                <span>Get stunning photos in <strong className="text-white">30-60 seconds</strong> with AI</span>
              </li>
              <li className="flex items-start gap-3">
                <Check className="w-5 h-5 text-[#D4A017] mt-0.5 flex-shrink-0" />
                <span>Unlimited enhancements for one flat monthly price</span>
              </li>
              <li className="flex items-start gap-3">
                <Check className="w-5 h-5 text-[#D4A017] mt-0.5 flex-shrink-0" />
                <span>Auto-generate social posts, emails, and property websites</span>
              </li>
              <li className="flex items-start gap-3">
                <Check className="w-5 h-5 text-[#D4A017] mt-0.5 flex-shrink-0" />
                <span>One platform for everything: photos → content → marketing</span>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </section>
  )
}

// ============================================
// FEATURES SECTION
// ============================================
const features = [
  { icon: Sun, title: 'Sky Replacement', description: 'Replace dull, overcast skies with stunning blue skies or dramatic sunsets instantly.' },
  { icon: Sparkles, title: 'HDR Enhancement', description: 'Bring out every detail with professional HDR that balances shadows and highlights.' },
  { icon: Home, title: 'Virtual Twilight', description: 'Transform daytime photos into beautiful dusk shots that sell faster.' },
  { icon: Eraser, title: 'Declutter', description: 'Remove unwanted objects, vehicles, and distractions with one click.' },
  { icon: Sofa, title: 'Virtual Staging', description: 'Add furniture and decor to empty rooms to help buyers visualize the space.' },
  { icon: TreePine, title: 'Lawn Enhancement', description: 'Turn brown, patchy lawns into lush green grass automatically.' },
  { icon: ImagePlus, title: 'Color Correction', description: 'Fix white balance, exposure, and color issues for true-to-life photos.' },
  { icon: Layers, title: 'Batch Processing', description: 'Apply the same enhancement to all photos in a listing at once.' }
]

function FeaturesSection() {
  return (
    <section id="features" className="py-20 bg-black">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <p className="text-[#D4A017] font-semibold mb-4">POWERFUL AI TOOLS</p>
          <h2 className="text-3xl md:text-5xl font-bold text-white mb-6">
            Everything You Need to Create
            <br />
            <span className="text-[#D4A017]">Stunning Listing Photos</span>
          </h2>
          <p className="text-white/60 max-w-2xl mx-auto">
            15+ AI-powered tools designed specifically for real estate photography. No Photoshop skills required.
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((feature, index) => (
            <div key={index} className="p-6 rounded-2xl bg-white/5 border border-white/10 hover:border-[#D4A017]/50 transition-all group">
              <div className="w-12 h-12 rounded-xl bg-[#D4A017]/10 flex items-center justify-center mb-4 group-hover:bg-[#D4A017]/20 transition-colors">
                <feature.icon className="w-6 h-6 text-[#D4A017]" />
              </div>
              <h3 className="text-white font-semibold mb-2">{feature.title}</h3>
              <p className="text-white/60 text-sm">{feature.description}</p>
            </div>
          ))}
        </div>

        <div className="text-center mt-12">
          <Link href="/signup" className="inline-flex items-center gap-2 px-8 py-4 bg-[#D4A017] hover:bg-[#B8860B] text-black font-bold rounded-xl transition-all">
            Try All Features Free
            <ArrowRight className="w-5 h-5" />
          </Link>
        </div>
      </div>
    </section>
  )
}

// ============================================
// CONTENT STUDIO SECTION
// ============================================
function ContentStudioSection() {
  return (
    <section className="py-20 bg-[#0a0a0a]">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div>
            <p className="text-[#D4A017] font-semibold mb-4">CONTENT STUDIO</p>
            <h2 className="text-3xl md:text-5xl font-bold text-white mb-6">
              Photos Enhanced.
              <br />
              <span className="text-[#D4A017]">Marketing Created.</span>
            </h2>
            <p className="text-white/60 mb-8">
              SnapR doesn't just enhance your photos — it creates your entire marketing campaign. 
              Social posts, emails, property websites, and videos. All generated automatically.
            </p>

            <div className="space-y-4 mb-8">
              {[
                { icon: Share2, text: '150+ social media templates for Instagram, Facebook, LinkedIn & more' },
                { icon: Mail, text: 'Professional email templates for every listing stage' },
                { icon: Globe, text: 'Instant property websites with your branding' },
                { icon: Video, text: 'Auto-generated listing videos with music & transitions' }
              ].map((item, i) => (
                <div key={i} className="flex items-start gap-3">
                  <div className="w-8 h-8 rounded-lg bg-[#D4A017]/10 flex items-center justify-center flex-shrink-0">
                    <item.icon className="w-4 h-4 text-[#D4A017]" />
                  </div>
                  <span className="text-white/80">{item.text}</span>
                </div>
              ))}
            </div>

            <Link href="/signup" className="inline-flex items-center gap-2 px-6 py-3 bg-[#D4A017] hover:bg-[#B8860B] text-black font-bold rounded-xl transition-all">
              Explore Content Studio
              <ArrowRight className="w-5 h-5" />
            </Link>
          </div>

          <div className="relative">
            <div className="absolute inset-0 bg-gradient-to-r from-[#D4A017]/20 to-transparent rounded-3xl blur-3xl" />
            <div className="relative bg-black/40 border border-white/10 rounded-2xl p-6">
              <div className="grid grid-cols-3 gap-4">
                {['Instagram', 'Facebook', 'Email', 'Website', 'Video', 'LinkedIn'].map((item, i) => (
                  <div key={i} className="aspect-square rounded-xl bg-white/5 border border-white/10 flex items-center justify-center text-white/60 text-sm hover:border-[#D4A017]/50 transition-colors cursor-pointer">
                    {item}
                  </div>
                ))}
              </div>
              <div className="mt-4 p-4 rounded-xl bg-[#D4A017]/10 border border-[#D4A017]/30">
                <p className="text-[#D4A017] text-sm font-medium">✨ 42 content pieces ready for this listing</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

// ============================================
// HOW IT WORKS SECTION
// ============================================
function HowItWorksSection() {
  const steps = [
    { number: '01', title: 'Upload Your Photos', description: 'Drag and drop your listing photos or shoot directly from your phone.' },
    { number: '02', title: 'AI Enhances Everything', description: 'Our AI analyzes each photo and applies professional enhancements automatically.' },
    { number: '03', title: 'Download & Publish', description: 'Get your enhanced photos plus ready-to-use marketing content in seconds.' }
  ]

  return (
    <section id="how-it-works" className="py-20 bg-black">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <p className="text-[#D4A017] font-semibold mb-4">HOW IT WORKS</p>
          <h2 className="text-3xl md:text-5xl font-bold text-white mb-6">
            From Upload to Published
            <br />
            <span className="text-[#D4A017]">In Under 60 Seconds</span>
          </h2>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {steps.map((step, index) => (
            <div key={index} className="relative">
              {index < 2 && (
                <div className="hidden md:block absolute top-12 left-[60%] w-[80%] h-0.5 bg-gradient-to-r from-[#D4A017]/50 to-transparent" />
              )}
              <div className="text-center">
                <div className="w-24 h-24 rounded-2xl bg-[#D4A017]/10 border border-[#D4A017]/30 flex items-center justify-center mx-auto mb-6">
                  <span className="text-3xl font-bold text-[#D4A017]">{step.number}</span>
                </div>
                <h3 className="text-xl font-bold text-white mb-3">{step.title}</h3>
                <p className="text-white/60">{step.description}</p>
              </div>
            </div>
          ))}
        </div>

        <div className="text-center mt-12">
          <Link href="/signup" className="inline-flex items-center gap-2 px-8 py-4 bg-[#D4A017] hover:bg-[#B8860B] text-black font-bold rounded-xl transition-all">
            Try It Now — Free
            <ArrowRight className="w-5 h-5" />
          </Link>
        </div>
      </div>
    </section>
  )
}

// ============================================
// PRICING SECTION
// ============================================
function PricingSection() {
  const plans = [
    {
      name: 'Starter', price: 19, description: 'Perfect for solo agents',
      features: ['50 photo enhancements/month', 'All 15+ AI tools', 'Basic content templates', 'Email support'],
      cta: 'Start Free Trial', highlighted: false
    },
    {
      name: 'Pro', price: 49, description: 'Most popular for professionals',
      features: ['200 photo enhancements/month', 'All 15+ AI tools', 'Full Content Studio access', 'Property websites', 'Video creator', 'Priority support'],
      cta: 'Start Free Trial', highlighted: true
    },
    {
      name: 'Agency', price: 99, description: 'For teams and brokerages',
      features: ['500 photo enhancements/month', 'Everything in Pro', 'Team collaboration (5 seats)', 'White-label exports', 'API access', 'Dedicated support'],
      cta: 'Contact Sales', highlighted: false
    }
  ]

  return (
    <section id="pricing" className="py-20 bg-[#0a0a0a]">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <p className="text-[#D4A017] font-semibold mb-4">SIMPLE PRICING</p>
          <h2 className="text-3xl md:text-5xl font-bold text-white mb-6">Start Free. Scale as You Grow.</h2>
          <p className="text-white/60 max-w-2xl mx-auto">No hidden fees. No per-image charges. Just simple, predictable pricing.</p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
          {plans.map((plan, index) => (
            <div key={index} className={`relative p-8 rounded-2xl ${plan.highlighted ? 'bg-[#D4A017]/10 border-2 border-[#D4A017]' : 'bg-white/5 border border-white/10'}`}>
              {plan.highlighted && (
                <div className="absolute -top-4 left-1/2 -translate-x-1/2 px-4 py-1 bg-[#D4A017] text-black text-sm font-bold rounded-full">MOST POPULAR</div>
              )}
              <h3 className="text-xl font-bold text-white mb-2">{plan.name}</h3>
              <p className="text-white/60 text-sm mb-4">{plan.description}</p>
              <div className="mb-6">
                <span className="text-4xl font-bold text-white">${plan.price}</span>
                <span className="text-white/60">/month</span>
              </div>
              <ul className="space-y-3 mb-8">
                {plan.features.map((feature, i) => (
                  <li key={i} className="flex items-start gap-2">
                    <Check className="w-5 h-5 text-[#D4A017] mt-0.5 flex-shrink-0" />
                    <span className="text-white/80 text-sm">{feature}</span>
                  </li>
                ))}
              </ul>
              <Link href="/signup" className={`block w-full py-3 rounded-xl font-semibold text-center transition-all ${plan.highlighted ? 'bg-[#D4A017] hover:bg-[#B8860B] text-black' : 'bg-white/10 hover:bg-white/20 text-white border border-white/20'}`}>
                {plan.cta}
              </Link>
            </div>
          ))}
        </div>

        <div className="text-center mt-12">
          <p className="text-white/60 text-sm">✨ 14-day free trial • No credit card required • Cancel anytime</p>
        </div>
      </div>
    </section>
  )
}

// ============================================
// TESTIMONIALS SECTION
// ============================================
function TestimonialsSection() {
  const testimonials = [
    { quote: "SnapR has completely transformed how I handle listing photos. What used to take days now takes minutes.", author: "Sarah M.", role: "Real Estate Agent, Keller Williams", rating: 5 },
    { quote: "The Content Studio alone is worth the subscription. I get weeks worth of social content from every listing.", author: "Michael R.", role: "Team Lead, RE/MAX", rating: 5 },
    { quote: "My clients are blown away by the virtual twilight photos. It's helped me win multiple listings.", author: "Jennifer L.", role: "Luxury Property Specialist", rating: 5 }
  ]

  return (
    <section className="py-20 bg-black">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <p className="text-[#D4A017] font-semibold mb-4">TESTIMONIALS</p>
          <h2 className="text-3xl md:text-5xl font-bold text-white mb-6">Loved by Real Estate Pros</h2>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <div key={index} className="p-8 rounded-2xl bg-white/5 border border-white/10">
              <div className="flex gap-1 mb-4">
                {[...Array(testimonial.rating)].map((_, i) => (
                  <Star key={i} className="w-5 h-5 fill-[#D4A017] text-[#D4A017]" />
                ))}
              </div>
              <p className="text-white/80 mb-6 italic">"{testimonial.quote}"</p>
              <div>
                <p className="text-white font-semibold">{testimonial.author}</p>
                <p className="text-white/60 text-sm">{testimonial.role}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

// ============================================
// CTA SECTION
// ============================================
function CTASection() {
  return (
    <section className="py-20 bg-[#0a0a0a]">
      <div className="max-w-4xl mx-auto px-6 text-center">
        <div className="p-12 rounded-3xl bg-gradient-to-br from-[#D4A017]/20 to-transparent border border-[#D4A017]/30">
          <h2 className="text-3xl md:text-5xl font-bold text-white mb-6">
            Ready to Transform Your
            <br />
            <span className="text-[#D4A017]">Listing Photos?</span>
          </h2>
          <p className="text-white/60 mb-8 max-w-xl mx-auto">
            Join thousands of real estate professionals who are saving time and winning more listings with SnapR.
          </p>
          <Link href="/signup" className="inline-flex items-center gap-2 px-8 py-4 bg-[#D4A017] hover:bg-[#B8860B] text-black font-bold rounded-xl text-lg transition-all">
            Start Your Free Trial
            <ArrowRight className="w-5 h-5" />
          </Link>
          <p className="text-white/40 text-sm mt-4">No credit card required • 14-day free trial</p>
        </div>
      </div>
    </section>
  )
}

// ============================================
// FOOTER
// ============================================
function Footer() {
  return (
    <footer className="py-12 bg-black border-t border-white/10">
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#D4A017] to-[#B8860B] flex items-center justify-center">
              <Camera className="w-5 h-5 text-black" />
            </div>
            <span className="text-xl font-bold text-white">Snap<span className="text-[#D4A017]">R</span></span>
          </div>
          <div className="flex flex-wrap items-center justify-center gap-6 text-white/60 text-sm">
            <a href="#" className="hover:text-white transition-colors">Features</a>
            <a href="#" className="hover:text-white transition-colors">Pricing</a>
            <a href="#" className="hover:text-white transition-colors">Support</a>
            <a href="#" className="hover:text-white transition-colors">Privacy</a>
            <a href="#" className="hover:text-white transition-colors">Terms</a>
          </div>
          <p className="text-white/40 text-sm">© 2025 SnapR. All rights reserved.</p>
        </div>
      </div>
    </footer>
  )
}

// ============================================
// MAIN PAGE
// ============================================
export default function LandingPage() {
  return (
    <main className="min-h-screen bg-black">
      <Navigation />
      <HeroSection />
      <ProblemSolutionSection />
      <FeaturesSection />
      <ContentStudioSection />
      <HowItWorksSection />
      <PricingSection />
      <TestimonialsSection />
      <CTASection />
      <Footer />
    </main>
  )
}
