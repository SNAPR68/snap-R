import OnboardingStep2 from "../step2";

export default function OnboardingStep2Page() {
  return <OnboardingStep2 />;
}

